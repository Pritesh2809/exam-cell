package com.kprcas.smartcell.smartcell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartcellApplicationTests {

	@Test
	void contextLoads() {
	}

}
